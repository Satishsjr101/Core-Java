//1) WAP to print a statement 1000 number of times
public class P1 {
    public static void main(String[] args) {
        int i, n = 1000;
        for (i = 1; i <= n; i++) {
            System.out.println("Jai Shree Krishna");
        }
    }
}