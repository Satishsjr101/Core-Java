//14) WAP to print alphabets in uppercase

public class P14 {
    public static void main(String ar[]) {

        for (char ch = 65; ch <= 90; ch++) {
            System.out.print(ch + " ");
        }

    }
}
