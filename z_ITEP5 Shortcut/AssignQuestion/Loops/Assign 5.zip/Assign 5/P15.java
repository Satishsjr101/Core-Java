//15) WAP to print alphabets in lowercase

public class P15 {
    public static void main(String ar[]) {

        for (char ch = 97; ch <= 122; ch++) {
            System.out.print(ch + " ");
        }

    }
}
